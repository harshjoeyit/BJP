
echo -e "lines : \c" 
wc -l < $1
echo -e "words : \c" 
wc -w < $1
echo -e "chars : \c" 
wc -c < $1