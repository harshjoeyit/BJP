read dir < file5.txt
ls $dir