

#!bash usr/bin/bash

find -iname "*.sh" -exec chmod +x {} \;

#makes all the files of type .sh in the directory executable 
