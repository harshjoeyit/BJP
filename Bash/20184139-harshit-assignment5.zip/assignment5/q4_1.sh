echo -e "directory: \c"
read dir 
ls $dir